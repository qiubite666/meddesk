# MedDesk v0.3.67 部署速览（linux-amd64，ops 多服务布局）

> 二进制已内嵌前端静态资源，**单文件运行，零外部依赖（CGO 关闭）**。
> 布局约定：meddesk 是 `/home/ops/service/` 下的独立子目录（可与其他服务并列），运行用户 `ops`。

```
/home/ops/service/meddesk/
├── meddesk          ← 二进制（本包提供）
├── .meddesk.env     ← 真实配置（点前缀，不进 git）
├── uploads/         ← 附件密文
└── fonts/           ← PDF 中文字体
```

前置：PostgreSQL 18（宿主机安装或 docker compose 均可，详见仓库 docs/DEPLOYMENT.md 第 2-3 节）。

## 0. 数据库与 Redis —— docker compose 方式（本包 deploy/ 已带所需文件）

```bash
# 拷到 compose 专用目录（./scripts/initdb 相对挂载依赖此位置）
sudo mkdir -p /home/ops/service/docker/meddesk/scripts/initdb
sudo cp deploy/docker-compose.middleware.yml deploy/postgres-tuning.conf \
  /home/ops/service/docker/meddesk/
sudo cp deploy/scripts/initdb/00-init.sql /home/ops/service/docker/meddesk/scripts/initdb/
cd /home/ops/service/docker/meddesk

cat > .env <<'EOF'
POSTGRES_USER=meddesk
POSTGRES_PASSWORD=<openssl rand -base64 24>
POSTGRES_DB=meddesk
PG_PORT=5432
REDIS_PASSWORD=<openssl rand -base64 24>
REDIS_PORT=6379
REDIS_MAXMEMORY=256mb
TZ=Asia/Shanghai
EOF
chmod 600 .env
# 本部署不加 swap：PG 500m / Redis 320m 均为硬顶（触顶自动重启，数据在卷中不丢）；
# 巡检：free -m 与 sudo docker stats --no-stream，available 持续 <100MB 时排查。
sudo docker compose -f docker-compose.middleware.yml up -d
sudo docker exec meddesk-pg psql -U meddesk -d meddesk -c 'SELECT version();'   # 18.6 即就绪
```

- 资源上限：PG 500m（配套 shared_buffers=128MB）/ Redis 320m；端口只绑 127.0.0.1
- 应用侧连接串：`MEDDESK_DB_URL=postgres://meddesk:<PG口令>@127.0.0.1:5432/meddesk?sslmode=disable`
- 停止（保留数据）：`down`；⚠️ `down -v` 删库，生产勿用

## 1. 安装

```bash
id ops >/dev/null 2>&1 || sudo useradd -m -s /bin/bash ops
sudo install -d -o ops -g ops -m 0750 /home/ops/service/meddesk \
  /home/ops/service/meddesk/data /home/ops/service/meddesk/fonts
sudo install -m 0755 meddesk /home/ops/service/meddesk/meddesk

# PDF 中文字体（缺失只影响 PDF 导出，其余功能正常）
sudo bash get-font.sh    # 下载到 /home/ops/service/meddesk/fonts/
```

## 2. 环境变量（真实配置 `.meddesk.env`，点前缀，不进 git）

```bash
sudo cp meddesk.env.example /home/ops/service/meddesk/.meddesk.env
sudo nano /home/ops/service/meddesk/.meddesk.env   # 替换 <...> 占位符
sudo chown root:ops /home/ops/service/meddesk/.meddesk.env && sudo chmod 640 /home/ops/service/meddesk/.meddesk.env
```

## 3. systemd

```bash
sudo cp systemd-meddesk.service /etc/systemd/system/meddesk.service
sudo systemctl daemon-reload && sudo systemctl enable --now meddesk
journalctl -u meddesk -n 20 --no-pager             # 表结构自动迁移；日志在 journald
```

## 4. Nginx + 证书（acme.sh ECC）

```bash
sudo cp nginx-meddesk.conf /etc/nginx/sites-available/meddesk.conf
sudo sed -i 's/med\.example\.com/你的域名/g' /etc/nginx/sites-available/meddesk.conf
sudo ln -sf /etc/nginx/sites-available/meddesk.conf /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# DNS 验证（无需 80 端口）：dns_xx 换成你的 DNS 提供商插件（cf/dp/aliyun…）
acme.sh --issue --dns dns_xx -d 你的域名 --keylength ec-256
acme.sh --install-cert -d 你的域名 --ecc \
  --fullchain-file /etc/letsencrypt/live/你的域名/fullchain.pem \
  --key-file       /etc/letsencrypt/live/你的域名/privkey.pem \
  --reloadcmd "sudo nginx -s reload"
```

## 5. 冒烟与首个账号

```bash
curl -fsS https://你的域名/api/v1/health
# {"status":"ok","version":"v0.3.67","db":"ok","cache":"degraded",...}
```

浏览器打开站点注册账号（临时把 `.meddesk.env` 的 `MEDDESK_SIGNUP_ENABLED=true` 重启后注册），注册完改回 `false` 并重启。

## 升级

```bash
sudo cp /home/ops/service/meddesk/meddesk /home/ops/service/meddesk/meddesk.bak.$(date +%F)
sudo install -m 0755 meddesk-new /home/ops/service/meddesk/meddesk
sudo systemctl restart meddesk
```

## 备份

```bash
pg_dump -Fc -U meddesk meddesk > meddesk-$(date +%F).dump    # 数据库（容器方式加 docker exec 前缀）
sudo tar czf data-$(date +%F).tar.gz -C /home/ops/service/meddesk data   # 附件密文
```

详细手册见仓库 `docs/DEPLOYMENT.md`；安全模型见 `docs/SECURITY.md`。
**忘记口令 = 数据不可恢复**，请妥善备份口令并每月在「设置」页导出 JSON 快照。
